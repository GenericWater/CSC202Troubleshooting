﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_Week1GUIexample
{
    public partial class FRMclass : Form
    {
        public FRMclass(string from1)
        {
            InitializeComponent();
            TBtxFromF1.Text = from1; // take the text from the textbox
        }

    }
}

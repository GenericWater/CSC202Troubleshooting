﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_Week1GUIexample
{
    public partial class FRMIntro : Form
    {
        public FRMIntro()
        {
            InitializeComponent();
        }

        private void BTNdoSomething_Click(object sender, EventArgs e)
        {
            // function inside of a class works just like a method
            MessageBox.Show("UAT Rocks!");
        }

        private void BTNf1CheckInt_Click(object sender, EventArgs e)
        {
            if (int.TryParse(TBf1Integer.Text, out int value)) 
            {
                MessageBox.Show("This is a valid integer");
            }
            else
            {
                MessageBox.Show("This is NOT a valid integer. Please try again!");
            }
        }

        private void CBf1Dog_CheckedChanged(object sender, EventArgs e)
        {
            // To add images to a project this way, they need to be in a directory ending in Debug
            // C:\Users\lelas\OneDrive\Documents\0-UAT Courses\7-CSC202-\ExampleC#Project\CSC202-Week1GUIexample\CSC202-Week1GUIexample\bin\Debug
            Image dog = Image.FromFile("dog.jpg");
            pictureBox1.Image = dog; 
        }

        private void CBf1Cat_CheckedChanged(object sender, EventArgs e)
        {
            Image cat = Image.FromFile("cat.jpg");
            pictureBox1.Image = cat;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void CBf1Lizard_CheckedChanged(object sender, EventArgs e)
        {
            Image lizard = Image.FromFile("lizard.jpg");
            pictureBox1.Image = lizard;
        }

        private void BTNgoToF2_Click(object sender, EventArgs e)
        {
            FRMclass frm = new FRMclass(textBox1.Text);
            this.Hide();// this = form that we are currently on (form1)
            frm.Show();
        }
    }
}

﻿namespace CSC202_Week1GUIexample
{
    partial class FRMIntro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMIntro));
            this.BTNdoSomething = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TBf1Integer = new System.Windows.Forms.TextBox();
            this.BTNf1CheckInt = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.CBf1Dog = new System.Windows.Forms.CheckBox();
            this.CBf1Cat = new System.Windows.Forms.CheckBox();
            this.CBf1Lizard = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BTNgoToF2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BTNdoSomething
            // 
            this.BTNdoSomething.Location = new System.Drawing.Point(859, 503);
            this.BTNdoSomething.Name = "BTNdoSomething";
            this.BTNdoSomething.Size = new System.Drawing.Size(131, 49);
            this.BTNdoSomething.TabIndex = 0;
            this.BTNdoSomething.Text = "Do Something!";
            this.BTNdoSomething.UseVisualStyleBackColor = true;
            this.BTNdoSomething.Click += new System.EventHandler(this.BTNdoSomething_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter an Integer!";
            // 
            // TBf1Integer
            // 
            this.TBf1Integer.Location = new System.Drawing.Point(146, 31);
            this.TBf1Integer.Name = "TBf1Integer";
            this.TBf1Integer.Size = new System.Drawing.Size(100, 22);
            this.TBf1Integer.TabIndex = 2;
            // 
            // BTNf1CheckInt
            // 
            this.BTNf1CheckInt.Location = new System.Drawing.Point(146, 72);
            this.BTNf1CheckInt.Name = "BTNf1CheckInt";
            this.BTNf1CheckInt.Size = new System.Drawing.Size(100, 60);
            this.BTNf1CheckInt.TabIndex = 3;
            this.BTNf1CheckInt.Text = "Verify Integer Here";
            this.BTNf1CheckInt.UseVisualStyleBackColor = true;
            this.BTNf1CheckInt.Click += new System.EventHandler(this.BTNf1CheckInt_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(782, 116);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(289, 240);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // CBf1Dog
            // 
            this.CBf1Dog.AutoSize = true;
            this.CBf1Dog.Location = new System.Drawing.Point(870, 26);
            this.CBf1Dog.Name = "CBf1Dog";
            this.CBf1Dog.Size = new System.Drawing.Size(93, 20);
            this.CBf1Dog.TabIndex = 5;
            this.CBf1Dog.Text = "I like dogs!";
            this.CBf1Dog.UseVisualStyleBackColor = true;
            this.CBf1Dog.CheckedChanged += new System.EventHandler(this.CBf1Dog_CheckedChanged);
            // 
            // CBf1Cat
            // 
            this.CBf1Cat.AutoSize = true;
            this.CBf1Cat.Location = new System.Drawing.Point(870, 53);
            this.CBf1Cat.Name = "CBf1Cat";
            this.CBf1Cat.Size = new System.Drawing.Size(87, 20);
            this.CBf1Cat.TabIndex = 6;
            this.CBf1Cat.Text = "I like cats!";
            this.CBf1Cat.UseVisualStyleBackColor = true;
            this.CBf1Cat.CheckedChanged += new System.EventHandler(this.CBf1Cat_CheckedChanged);
            // 
            // CBf1Lizard
            // 
            this.CBf1Lizard.AutoSize = true;
            this.CBf1Lizard.Location = new System.Drawing.Point(870, 80);
            this.CBf1Lizard.Name = "CBf1Lizard";
            this.CBf1Lizard.Size = new System.Drawing.Size(101, 20);
            this.CBf1Lizard.TabIndex = 7;
            this.CBf1Lizard.Text = "I like lizards!";
            this.CBf1Lizard.UseVisualStyleBackColor = true;
            this.CBf1Lizard.CheckedChanged += new System.EventHandler(this.CBf1Lizard_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 283);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(279, 22);
            this.textBox1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Enter text to transfer!";
            // 
            // BTNgoToF2
            // 
            this.BTNgoToF2.Location = new System.Drawing.Point(81, 322);
            this.BTNgoToF2.Name = "BTNgoToF2";
            this.BTNgoToF2.Size = new System.Drawing.Size(132, 46);
            this.BTNgoToF2.TabIndex = 10;
            this.BTNgoToF2.Text = "Go to Form 2";
            this.BTNgoToF2.UseVisualStyleBackColor = true;
            this.BTNgoToF2.Click += new System.EventHandler(this.BTNgoToF2_Click);
            // 
            // FRMIntro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1073, 613);
            this.Controls.Add(this.BTNgoToF2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.CBf1Lizard);
            this.Controls.Add(this.CBf1Cat);
            this.Controls.Add(this.CBf1Dog);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BTNf1CheckInt);
            this.Controls.Add(this.TBf1Integer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTNdoSomething);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FRMIntro";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNdoSomething;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBf1Integer;
        private System.Windows.Forms.Button BTNf1CheckInt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox CBf1Dog;
        private System.Windows.Forms.CheckBox CBf1Cat;
        private System.Windows.Forms.CheckBox CBf1Lizard;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTNgoToF2;
    }
}

